package com.rbu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LombokDemo1Application {

	public static void main(String[] args) {
		SpringApplication.run(LombokDemo1Application.class, args);
	}

}
