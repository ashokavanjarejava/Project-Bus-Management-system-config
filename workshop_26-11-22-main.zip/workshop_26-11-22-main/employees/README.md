Mockito: 
How to test Spring Boot Application, Controllers and Services
