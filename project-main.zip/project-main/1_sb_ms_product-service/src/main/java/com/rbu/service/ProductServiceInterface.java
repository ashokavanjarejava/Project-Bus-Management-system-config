package com.rbu.service;

import com.rbu.dto.ProductDto;

public interface ProductServiceInterface {
	
	public ProductDto createProduct(ProductDto dto);

}
