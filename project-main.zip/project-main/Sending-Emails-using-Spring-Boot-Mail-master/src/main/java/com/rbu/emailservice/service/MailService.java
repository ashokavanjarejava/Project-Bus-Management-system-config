package com.rbu.emailservice.service;

import com.rbu.emailservice.model.Mail;

public interface MailService 
{
	public void sendEmail(Mail mail);
}
