package com.pixeltrice.springbootpaytmpayment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootPaytmPaymentApplicationTests {

	@Test
	void contextLoads() {
	}

}
