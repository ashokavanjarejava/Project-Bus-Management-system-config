package com.rbu.logapp.log_audit_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class LogAuditServiceApplication {

    public static void main(final String[] args) {
        SpringApplication.run(LogAuditServiceApplication.class, args);
    }

}
