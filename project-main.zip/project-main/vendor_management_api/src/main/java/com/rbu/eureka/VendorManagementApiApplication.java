package com.rbu.eureka;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VendorManagementApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(VendorManagementApiApplication.class, args);
	}

}
